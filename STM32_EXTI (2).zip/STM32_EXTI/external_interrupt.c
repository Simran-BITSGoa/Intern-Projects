#include "stm32f4xx.h" 

// Function prototypes
void EXTI3_IRQHandler(void);
void UART4_init(void);
void UART4_write(int c);
void delayMs(int);

void EXTI3_IRQHandler(void) {
    if ((EXTI->PR & EXTI_PR_PR3) != 0) {
        // Clear flag by writing 1
        EXTI->PR |= EXTI_PR_PR3;

        // Transmiting "Yes" via UART4
        char response[] = "Yes\r\n";
        for (int i = 0; i < 5; i++) {
            UART4_write(response[i]);
        }
    }
}

int main(void) {
    char message[] = "Hello\r\n";
    int i;

    // Initialize UART4
    UART4_init();

    // Enable GPIOA clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    // Configure PA3 as input with pull-down
    GPIOA->MODER &= ~(3U << (3 * 2)); // Input mode for PA3
    GPIOA->PUPDR &= ~(3U << (3 * 2));
    GPIOA->PUPDR |= (2U << (3 * 2));

    // Enable SYSCFG clock
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

    // Connect EXTI line 3 to PA3
    SYSCFG->EXTICR[0] &= ~SYSCFG_EXTICR1_EXTI3;
    SYSCFG->EXTICR[0] |= SYSCFG_EXTICR1_EXTI3_PA;

    // Unmask EXTI line 3 and configure rising edge trigger
    EXTI->IMR |= EXTI_IMR_IM3;
    EXTI->RTSR |= EXTI_RTSR_TR3;
    EXTI->FTSR &= ~EXTI_FTSR_TR3;

    // Enable EXTI3 interrupt in NVIC
    NVIC_EnableIRQ(EXTI3_IRQn);

    // Main loop
    while (1) {
        for (i = 0; i < 7; i++) {
            UART4_write(message[i]); /* sending a char */
        }
        delayMs(10); 
    }
}

/* Initialize UART4 pins and Baudrate */
void UART4_init(void) {
    RCC->AHB1ENR |= 1; /* Enable GPIOA clock */
    RCC->APB1ENR |= 0x80000; /* Enable UART4 clock */

    /* Configure PA0 for UART4 TX */
    GPIOA->AFR[0] &= ~0x000F;
    GPIOA->AFR[0] |= 0x0008; /* alt8 for UART4 */
    GPIOA->MODER &= ~0x0003;
    GPIOA->MODER |= 0x0002; /* enable alternate function for PA0 */

    UART4->BRR = 0x0683; /* 9600 baud @ 16 MHz */
    UART4->CR1 = 0x0008; /* enable Tx, 8-bit data */
    UART4->CR2 = 0x0000; /* 1 stop bit */
    UART4->CR3 = 0x0000; /* no flow control */
    UART4->CR1 |= 0x2000; /* enable UART4 */
}

/* Writing a character to UART4 */
void UART4_write(int ch) {
    while (!(UART4->SR & 0x0080)) {} // waiting until Tx buffer empty
    UART4->DR = (ch & 0xFF);
}

/* Delay function */
void delayMs(int n) {
    int i;
    for (; n > 0; n--)
        for (i = 0; i < 2000; i++) ;
}
