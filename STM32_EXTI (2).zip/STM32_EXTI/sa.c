#include <stm32f10x_lib.h> // STM32F10x Library Definitions

unsigned int ledPosExti = 0; // LED position (from 0..7) for EXTI
unsigned int ledExti = 0;

/* Function Prototypes */
void USART1_Init(void);
void USART1_SendString(const char *str);

/*----------------------------------------------------------------------------
  EXTI15..10 Interrupt Handler for S2 button connected to GPIOC.13
 ----------------------------------------------------------------------------/
void EXTI15_10_IRQHandler(void) {
  if (EXTI->PR & (1 << 13)) { // Check if EXTI13 interrupt is pending
    EXTI->PR |= (1 << 13);    // Clear pending interrupt

    // Print message via USART
    USART1_SendString("S2 Button Pressed");

    // Toggle LED state for visual feedback
    if ((ledExti ^= 1) == 0)
      GPIOB->ODR &= ~(1 << (ledPosExti + 8)); // Turn off LED
    else
      GPIOB->ODR |= (1 << (ledPosExti + 8));  // Turn on LED
  }
}

void USART1_Init(void) {
  RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN; // Enable GPIOA and USART1 clocks

  // Configure PA9 (TX) as Alternate Function Push-Pull
  GPIOA->CRH &= ~(GPIO_CRH_MODE9 | GPIO_CRH_CNF9);
  GPIOA->CRH |= (GPIO_CRH_MODE9_1 | GPIO_CRH_MODE9_0 | GPIO_CRH_CNF9_1);

  // Configure PA10 (RX) as Input Floating
  GPIOA->CRH &= ~(GPIO_CRH_MODE10 | GPIO_CRH_CNF10);
  GPIOA->CRH |= GPIO_CRH_CNF10_0;

  // Configure USART1
  USART1->BRR = 0x0383;       
  USART1->CR1 |= USART_CR1_TE; // Enable Transmitter
  USART1->CR1 |= USART_CR1_UE; // Enable USART1
}

/*----------------------------------------------------------------------------
  Send a String via USART1
 ----------------------------------------------------------------------------/
void USART1_SendString(const char *str) {
  while (*str) {
    USART1->DR = (*str++ & 0xFF); // Write character to Data Register
    while (!(USART1->SR & USART_SR_TXE)); // Wait until TXE (Transmit Data Register Empty)
  }
}

/*----------------------------------------------------------------------------
  GPIO and EXTI Initialization
 ----------------------------------------------------------------------------/
void GPIO_EXTI_Init(void) {
  RCC->APB2ENR |= RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN; // Enable GPIOB, GPIOC, and AFIO clocks

  // Configure PC.13 as Input with Pull-Up (S2 Button)
  GPIOC->CRH &= ~(GPIO_CRH_MODE13 | GPIO_CRH_CNF13);
  GPIOC->CRH |= GPIO_CRH_CNF13_1; // Input with pull-up/down
  GPIOC->ODR |= GPIO_ODR_ODR13;   // Enable pull-up

  // Configure PB.8 as Output for LED
  GPIOB->CRH &= ~(GPIO_CRH_MODE8 | GPIO_CRH_CNF8);
  GPIOB->CRH |= GPIO_CRH_MODE8_1 | GPIO_CRH_MODE8_0; // Output mode, max speed 50 MHz
  GPIOB->CRH &= ~GPIO_CRH_CNF8;                      // Push-pull output

  // Map EXTI13 to PC.13
  AFIO->EXTICR[3] = AFIO_EXTICR4_EXTI13_PC;

  // Configure EXTI13 for Falling Edge Trigger
  EXTI->IMR |= (1 << 13);  // Enable interrupt mask for EXTI13
  EXTI->FTSR |= (1 << 13); // Falling edge trigger

  // Enable EXTI15_10 Interrupt in NVIC
  NVIC_SetPriority(EXTI15_10_IRQn, 2); // Set priority
  NVIC_EnableIRQ(EXTI15_10_IRQn);      // Enable interrupt
}

/*----------------------------------------------------------------------------
  Main Function
 ----------------------------------------------------------------------------/
int main(void) {
  USART1_Init();      // Initialize USART1 for debugging
  GPIO_EXTI_Init();   // Initialize GPIO and EXTI

  while (1) {
    // Main loop does nothing, everything is interrupt-driven
  }
}