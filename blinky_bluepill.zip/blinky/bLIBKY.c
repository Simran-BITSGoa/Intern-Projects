
#include "stm32f10x.h"

void delay_ms(uint32_t ms);

int main(void) {
    // Enable clock for GPIOC
    RCC->APB2ENR |= RCC_APB2ENR_IOPCEN;

    // Set PC13 as output (push-pull, max speed 2 MHz)
    GPIOC->CRH &= ~(GPIO_CRH_MODE13 | GPIO_CRH_CNF13);  // Clear settings
    GPIOC->CRH |= (GPIO_CRH_MODE13_1);  // Output mode, max speed 2 MHz

    while (1) {
        GPIOC->ODR ^= GPIO_ODR_ODR13;  // Toggle LED (PC13)
        delay_ms(500);  // 500ms delay
    }
}

void delay_ms(uint32_t ms) {
    for (uint32_t i = 0; i < ms * 4000; i++) {
        __NOP();  // No operation (wastes a small amount of time)
    }
}
